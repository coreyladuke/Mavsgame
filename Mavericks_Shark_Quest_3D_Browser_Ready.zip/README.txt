MAVERICK’S SHARK QUEST 3D

This is an interactive HTML browser game, not a video or an Android APK. The ChatGPT file preview may show only a blue screen because JavaScript is blocked in previews. To play on iPhone Safari or Android Chrome, first upload index.html to an HTTPS static game host (for example itch.io or GitHub Pages). Then open the published game web address in the browser.

If the game opens: tap START AQUA’S ADVENTURE.

This package is not yet publicly hosted.
